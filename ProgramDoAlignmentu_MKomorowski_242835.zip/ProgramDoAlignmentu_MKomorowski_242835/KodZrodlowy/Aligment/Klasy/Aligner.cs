using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment.Klasy
{
    public class Aligner
    {
        public IAlgorytm algorytm = null;
        private ISequence sekwencja1 = null;
        private ISequence sekwencja2 = null;

        private AbsMacierzAlignmentu matrix = null;
        private List<SingleAlignment> aligmentResult = null;

        private bool obliczoneAlignmenty = false;


        public Aligner(ISequence sekwencjaDoAlignmentu1, ISequence sekwencjaDoAlignmentu2, AbsMacierzAlignmentu macierz)
        {
            this.algorytm = LoadAlgorithm();
            this.sekwencja1 = sekwencjaDoAlignmentu1;
            this.sekwencja2 = sekwencjaDoAlignmentu2;
            this.matrix = macierz;
            this.obliczoneAlignmenty = false;
        }

        private IAlgorytm LoadAlgorithm()
        {
            if (ProgramConfig.set_AlignmentType == ProgramConfig.AlignmentType.NeedlemanWunsch)
                return new NeedlemanWunschAlgorithm();
            if (ProgramConfig.set_AlignmentType == ProgramConfig.AlignmentType.SmithWaterman)
                return new SmithWatermanAlgorithm();
            else return null;
        }

        public void ObliczAlignmenty()
        {
            if (!obliczoneAlignmenty)
            {
                this.aligmentResult = new List<SingleAlignment>();
                this.obliczoneAlignmenty = true;
                this.algorytm.ObliczMacierzAlignmentu(this.matrix);
                int x, y, max;
                matrix.ZnajdzMaksymaln�Warto��IJejIndeksy(out max, out x, out y);

                if (ProgramConfig.set_AlignmentType == ProgramConfig.AlignmentType.SmithWaterman && ProgramConfig.set_similarityThreshold > max)
                    return;

                Console.WriteLine("-----------------------------------------------------------------");
                Console.WriteLine("--- NOWY ALIGNMENT                                            ---");
                Console.WriteLine("-----------------------------------------------------------------");


                Console.WriteLine("\nMax Score: " + max.ToString());

                this.algorytm.ZnajdzAlignmenty(this.matrix, this.aligmentResult);

            }

            PodajWynikAlignmentu();
            Console.WriteLine("-----------------------------------------------------------------");
            Console.WriteLine("--- KONIEC ALIGNMENTU                                         ---  ");
            Console.WriteLine("-----------------------------------------------------------------");
            Console.WriteLine("\n\n\n");
        }

        public void PodajWynikAlignmentu()
        {
            Console.WriteLine("\nStartowe sekwencje: ");
            Console.WriteLine("1. " + sekwencja1.Zwr��Litery());
            Console.WriteLine("D�ugo�� sekwencji: {0}", sekwencja1.D�ugo��Sekwencji());
            Console.WriteLine(sekwencja1.Zwr��Info());
            Console.WriteLine();
            Console.WriteLine("2. " + sekwencja2.Zwr��Litery());
            Console.WriteLine("D�ugo�� sekwencji: {0}", sekwencja2.D�ugo��Sekwencji());
            Console.WriteLine(sekwencja2.Zwr��Info());
            foreach (var align in aligmentResult)
            {
                align.Wyswietl();
            }

            if (ProgramConfig.set_ShowAlignmentMatrix == ProgramConfig.ShowAlignmentMatrix.Yes)
            {
                matrix.Wy�wietl();
            }

        }
    }
}
