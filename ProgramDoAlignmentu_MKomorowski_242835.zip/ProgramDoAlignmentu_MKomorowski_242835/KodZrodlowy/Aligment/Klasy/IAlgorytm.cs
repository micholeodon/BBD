using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment.Klasy
{
    public interface IAlgorytm
    {
        void ObliczMacierzAlignmentu(AbsMacierzAlignmentu matrix);
        void ZnajdzAlignmenty(AbsMacierzAlignmentu matrix, List<SingleAlignment> alignmentResult);
        int F(AbsMacierzAlignmentu matrix, int i, int j);
       

    }
}
