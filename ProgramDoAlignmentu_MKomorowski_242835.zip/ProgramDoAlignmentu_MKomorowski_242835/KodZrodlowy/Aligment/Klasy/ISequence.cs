﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment.Klasy
{
    public interface ISequence
    {
        string ZwróćLitery();
        string ZwróćLiteryPlusSpacjaNaPoczątku();
        int DługośćSekwencji();
        void DodajInfo(string info);
        string ZwróćInfo();
    }
}
