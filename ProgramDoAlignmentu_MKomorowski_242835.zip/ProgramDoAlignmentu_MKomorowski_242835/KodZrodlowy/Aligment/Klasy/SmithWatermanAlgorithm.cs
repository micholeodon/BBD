﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment.Klasy
{
    public class SmithWatermanAlgorithm : IAlgorytm
    {
        public IScoring scoring;


        /// <summary>
        /// Inicjacja algorytmu Smitha-Watermana z domyślnymi wagami.
        /// </summary>
        public SmithWatermanAlgorithm()
        {
            this.scoring = LoadScoring();
        }


        public void ObliczMacierzAlignmentu(AbsMacierzAlignmentu matrix)
        {
            string kodSeq1_zeSpacja = matrix.sekwencja1.ZwróćLiteryPlusSpacjaNaPoczątku();
            string kodSeq2_zeSpacja = matrix.sekwencja2.ZwróćLiteryPlusSpacjaNaPoczątku();

            for (int i = 0; i < kodSeq1_zeSpacja.Length; i++)
            {
                for (int j = 0; j < kodSeq2_zeSpacja.Length; j++)
                {
                    matrix.Wartości[i, j] = F(matrix, i, j);
                }
            }
        }

        public void ZnajdzAlignmenty(AbsMacierzAlignmentu matrix, List<SingleAlignment> alignmentResult)
        {
            int max, max_I, max_J;
            matrix.ZnajdzMaksymalnąWartośćIJejIndeksy(out max, out max_I, out max_J);

            alignmentResult.Add(new SingleAlignment());

            int matrixSizeX = matrix.Kierunki.GetLength(0);
            int matrixSizeY = matrix.Kierunki.GetLength(1);

            int posI = max_I;
            int posJ = max_J;

            while (czyDalejPrzegladacMacierz(matrix.Wartości, posI, posJ))
            {
                var result = matrix.Kierunki[posI, posJ];

                if (result == AbsMacierzAlignmentu.Kierunek.Skos)
                {
                    alignmentResult[0].FirstSeq += matrix.sekwencja1.ZwróćLiteryPlusSpacjaNaPoczątku()[posI];
                    alignmentResult[0].SecondSeq += matrix.sekwencja2.ZwróćLiteryPlusSpacjaNaPoczątku()[posJ];
                    if (matrix.sekwencja1.ZwróćLiteryPlusSpacjaNaPoczątku()[posI] == matrix.sekwencja2.ZwróćLiteryPlusSpacjaNaPoczątku()[posJ]) alignmentResult[0].Indicators += "|";
                    else alignmentResult[0].Indicators += " ";
                    posI--; posJ--;
                    continue;
                }
                if (result == AbsMacierzAlignmentu.Kierunek.Lewo)
                {
                    alignmentResult[0].FirstSeq += "-";
                    alignmentResult[0].Indicators += " ";
                    alignmentResult[0].SecondSeq += matrix.sekwencja2.ZwróćLiteryPlusSpacjaNaPoczątku()[posJ];
                    posJ--;
                    continue;
                }
                if (result == AbsMacierzAlignmentu.Kierunek.Góra)
                {
                    alignmentResult[0].FirstSeq += matrix.sekwencja1.ZwróćLiteryPlusSpacjaNaPoczątku()[posI];
                    alignmentResult[0].Indicators += " ";
                    alignmentResult[0].SecondSeq += "-";
                    posI--;
                    continue;
                }
            }

            alignmentResult[0].Reverse();
        }

        private IScoring LoadScoring()
        {
            if (ProgramConfig.set_ScoringType == ProgramConfig.ScoringType.Standard)
                return new StandardScoring(ProgramConfig.set_sameLetterScore, ProgramConfig.set_differentLetterScore, ProgramConfig.set_gapScore);
            if (ProgramConfig.set_ScoringType == ProgramConfig.ScoringType.SubstitutionMatrix)
                return new SMScoring();
            else return null;
        }

        private static bool czyDalejPrzegladacMacierz(int[,] values, int posI, int posJ)
        {
            return !(values[posI, posJ] == 0);
        }

        public int F(AbsMacierzAlignmentu matrix, int i, int j)
        {
            char litera1 = matrix.sekwencja1.ZwróćLiteryPlusSpacjaNaPoczątku()[i];
            char litera2 = matrix.sekwencja2.ZwróćLiteryPlusSpacjaNaPoczątku()[j];



            if (i == 0 && j == 0) return 0;
            if (i == 0 || j == 0) return Math.Max(0, scoring.SpaceScore());

            int s = scoring.ComparisonScore(litera1, litera2);

            int a = matrix.Wartości[i - 1, j - 1] + s;
            int b = matrix.Wartości[i - 1, j] + scoring.SpaceScore();
            int c = matrix.Wartości[i, j - 1] + scoring.SpaceScore();

            int[] scores = { 0, a, b, c };
            int max = scores.Max();


            if (max == c) matrix.Kierunki[i, j] = AbsMacierzAlignmentu.Kierunek.Lewo;
            if (max == b) matrix.Kierunki[i, j] = AbsMacierzAlignmentu.Kierunek.Góra;
            if (max == a) matrix.Kierunki[i, j] = AbsMacierzAlignmentu.Kierunek.Skos;
            if (max == 0) matrix.Kierunki[i, j] = AbsMacierzAlignmentu.Kierunek.Brak;

            return max;
        }
    }
}
