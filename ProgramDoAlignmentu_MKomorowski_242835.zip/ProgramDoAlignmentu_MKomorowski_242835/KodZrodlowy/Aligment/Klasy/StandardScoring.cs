﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment.Klasy
{
    public class StandardScoring : IScoring
    {
        private int xxScore;
        private int xyScore;
        private int spceScore;

        public StandardScoring(int sameLettersScore, int differentLettersScore, int spaceScore)
        {
            this.xxScore = sameLettersScore;
            this.xyScore = differentLettersScore;
            this.spceScore = spaceScore;
        }

        public int ComparisonScore(char letter1, char letter2)
        {
            if (letter1 == letter2) return xxScore;
            else return xyScore;
        }

        public int SpaceScore()
        {
            return spceScore;
        }
    }
}
