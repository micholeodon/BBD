﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment.Klasy
{
    public class UserMenu
    {
        public static void Configure()
        {
            #region Choice of program mode
            bool ok = false;
            while (!ok)
            {
                Console.WriteLine("Typ programu:");
                Console.WriteLine("1. Single alignment (1-1),");
                Console.WriteLine("2. Database-target (many-many),");
                int choice = ReadChoice();
                ok = checkChoice(choice);
                if (choice == 1)
                    ProgramConfig.set_ProgramMode = ProgramConfig.ProgramMode.SingleAlignment;
                else if (choice == 2)
                    ProgramConfig.set_ProgramMode = ProgramConfig.ProgramMode.DbAlignment;
                else ok = false;
            }

            Console.WriteLine(); 
            #endregion

            #region Choice of alignment type
            ok = false;
            while (!ok)
            {
                Console.WriteLine("Typ uliniowienia:");
                Console.WriteLine("1. Globalne (Needleman-Wunsch),");
                Console.WriteLine("2. Lokalne (Smith-Waterman),");
                int choice = ReadChoice();
                ok = checkChoice(choice);
                if (choice == 1)
                    ProgramConfig.set_AlignmentType = ProgramConfig.AlignmentType.NeedlemanWunsch;
                else if (choice == 2)
                    ProgramConfig.set_AlignmentType = ProgramConfig.AlignmentType.SmithWaterman;
                else ok = false;
            }

            Console.WriteLine(); 
            #endregion

            #region Set similarity threshold value
            if (ProgramConfig.set_AlignmentType == ProgramConfig.AlignmentType.SmithWaterman)
            {
                ok = false;
                while (!ok)
                {
                    Console.WriteLine("Wybrano algorytm Smitha-Watermana.");
                    Console.WriteLine("Jaka wartosc progu podobienstwa? (minimal MAX SCORE) ");
                    int val = ReadVal();
                    ProgramConfig.set_similarityThreshold = val;
                    ok = checkVal(val);
                }

                Console.WriteLine();
            } 
            #endregion

            #region Choice of scoring type
            ok = false;
            while (!ok)
            {
                Console.WriteLine("Typ punktacji:");
                Console.WriteLine("1. Standard,");
                Console.WriteLine("2. Substitution Matrix,");
                int choice = ReadChoice();
                ok = checkChoice(choice);
                if (choice == 1)
                    ProgramConfig.set_ScoringType = ProgramConfig.ScoringType.Standard;
                else if (choice == 2)
                    ProgramConfig.set_ScoringType = ProgramConfig.ScoringType.SubstitutionMatrix;
                else ok = false;
            }

            Console.WriteLine();

            #endregion

            #region Set values of standard scoring
            if (ProgramConfig.set_ScoringType == ProgramConfig.ScoringType.Standard)
            {
                ok = false;
                while (!ok)
                {
                    Console.WriteLine("Wybrano standardową punktację.");
                    Console.WriteLine("Ile punktow za zgodność? (MATCH)");
                    int val = ReadVal();
                    ProgramConfig.set_sameLetterScore = val;
                    ok = checkVal(val);
                }

                Console.WriteLine();

                ok = false;
                while (!ok)
                {
                    Console.WriteLine("Ile punktow za niezgodność? (MISMATCH)");
                    int val = ReadVal();
                    ProgramConfig.set_differentLetterScore = val;
                    ok = checkVal(val);
                }

                Console.WriteLine();

                ok = false;
                while (!ok)
                {
                    Console.WriteLine("Ile punktow za przerwę? (GAP)");
                    int val = ReadVal();
                    ProgramConfig.set_gapScore = val;
                    ok = checkVal(val);
                }

                Console.WriteLine();
            }
            #endregion

            #region Choice of substitution matrix
            if (ProgramConfig.set_ScoringType == ProgramConfig.ScoringType.SubstitutionMatrix)
            {
                ok = false;
                while (!ok)
                {
                    Console.WriteLine("Wybrano ocenę za pomocą macierzy substytucji");
                    Console.WriteLine("Typ macierzy:");
                    Console.WriteLine("1. PAM250,");
                    Console.WriteLine("2. BLOSUM50,");
                    Console.WriteLine("3. BLOSUM62");
                    int choice = ReadChoice();
                    ok = checkChoice(choice);
                    if (choice == 1)
                    {
                        string filename = "PAM250.txt";
                        ok = checkFileName(filename);

                        if (ok)
                        {
                            string[] files = getFilesFullPaths(filename);
                            ProgramConfig.set_substituteMatrixPath = files[0];
                        }
                        else
                            Console.WriteLine("Nie można znaleźć pliku PAM250.txt !");
                        
                    }
                    else if (choice == 2)
                    {
                        string filename = "BLOSUM50.txt";
                        ok = checkFileName(filename);

                        if (ok)
                        {
                            string[] files = getFilesFullPaths(filename);
                            ProgramConfig.set_substituteMatrixPath = files[0];
                        }
                        else
                            Console.WriteLine("Nie można znaleźć pliku BLOSUM50.txt !");
                    }
                    else if (choice == 3)
                    {
                        string filename = "BLOSUM62.txt";
                        ok = checkFileName(filename);

                        if (ok)
                        {
                            string[] files = getFilesFullPaths(filename);
                            ProgramConfig.set_substituteMatrixPath = files[0];
                        }
                        else
                            Console.WriteLine("Nie można znaleźć pliku BLOSUM62.txt !");
                    }
                    else ok = false;
                }

                Console.WriteLine();
            } 
            #endregion

            #region Single alignment: set file with two sequences
            if (ProgramConfig.set_ProgramMode == ProgramConfig.ProgramMode.SingleAlignment)
            {
                ok = false;
                while (!ok)
                {
                    Console.WriteLine("Podaj nazwę pliku z parą sekwencji do porównania (not case-sensitive):");
                    string filename = ReadFileName();
                    ok = checkFileName(filename);

                    if (ok)
                    {
                        string[] files = getFilesFullPaths(filename);
                        ProgramConfig.set_singleAligmentPath = files[0];
                    }
                }

                Console.WriteLine();
            } 
            #endregion

            #region dbAlignment: set db file
            if (ProgramConfig.set_ProgramMode == ProgramConfig.ProgramMode.DbAlignment)
            {
                ok = false;
                while (!ok)
                {
                    Console.WriteLine("Podaj nazwę pliku z bazą sekwencji (not case-sensitive):");
                    string filename = ReadFileName();
                    ok = checkFileName(filename);

                    if (ok)
                    {
                        string[] files = getFilesFullPaths(filename);
                        ProgramConfig.set_dbPath = files[0];
                    }
                }

                Console.WriteLine();
            } 
            #endregion

            #region dbAlignment: set target file
            if (ProgramConfig.set_ProgramMode == ProgramConfig.ProgramMode.DbAlignment)
            {
                ok = false;
                while (!ok)
                {
                    Console.WriteLine("Podaj nazwę pliku z sekwencjami do porównania z sekwencjami z bazą danych (not case-sensitive):");
                    string filename = ReadFileName();
                    ok = checkFileName(filename);

                    if (ok)
                    {
                        string[] files = getFilesFullPaths(filename);
                        ProgramConfig.set_targetSequencesPath = files[0];
                    }
                }

                Console.WriteLine();
            } 
            #endregion

            #region Alignment Matrix Display
            ok = false;
            while (!ok)
            {
                Console.WriteLine("Czy chcesz wyświetlać macierz alignmentu?");
                Console.WriteLine("1. Nie,");
                Console.WriteLine("2. Tak.");
                int choice = ReadChoice();
                ok = checkChoice(choice);
                if (choice == 1)
                    ProgramConfig.set_ShowAlignmentMatrix = ProgramConfig.ShowAlignmentMatrix.No;
                else if (choice == 2)
                    ProgramConfig.set_ShowAlignmentMatrix = ProgramConfig.ShowAlignmentMatrix.Yes;
                else ok = false;
            }

            Console.WriteLine();
            #endregion

            #region Show next mode setting (ENTER mode)
            ok = false;
            while (!ok)
            {
                Console.WriteLine("ENTER by przejść do następnego wyniku?");
                Console.WriteLine("1. Nie,");
                Console.WriteLine("2. Tak.");
                int choice = ReadChoice();
                ok = checkChoice(choice);
                if (choice == 1)
                    ProgramConfig.set_EnterMode = ProgramConfig.ENTER.No;
                else if (choice == 2)
                    ProgramConfig.set_EnterMode = ProgramConfig.ENTER.Yes;
                else ok = false;
            }

            Console.WriteLine();
            #endregion

            Console.WriteLine();
        }

        private static string[] getFilesFullPaths(string regex)
        {
            string[] fileFolder = new string[] { };
            fileFolder = Directory.GetDirectories(Directory.GetCurrentDirectory(), "Files", SearchOption.AllDirectories);
            string[] files = new string[] { };
            files = Directory.GetFiles(fileFolder[0], regex);
            return files;
        }


        private static string ReadFileName()
        {
            string line = Console.ReadLine();
            return line;
        }
        
        private static bool checkFileName(string filename)
        {
            if (!File.Exists(ProgramConfig.filesDirectory + @"\" + filename))
                return false;
            else
                return true;
        }

        private static int ReadVal()
        {
            string line = Console.ReadLine();
            int val;
            bool succeded = Int32.TryParse(line, out val);

            if (succeded)
                return val;
            else
                return Int32.MinValue;
        }
        
        private static bool checkVal(int val)
        {
            if (val == Int32.MinValue)
                return false;
            else
                return true;
        }


        private static int ReadChoice()
        {
            string line = Console.ReadLine();
            int choice;
            bool succeded = Int32.TryParse(line, out choice);

            if (succeded)
                return choice;
            else
                return -1;
        }

        private static bool checkChoice(int choice)
        {
            if (choice == -1)
                return false;
            else
                return true;
        }


    }
}
