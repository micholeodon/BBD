using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment.Klasy
{
    public abstract class AbsMacierzAlignmentu
    {
        public ISequence  sekwencja1 = null;
        public ISequence  sekwencja2 = null;

        public enum Kierunek : int
        {
            Brak = 0,
            Lewo = -1,
            Skos = 2,
            Góra = 1
        };

        public AbsMacierzAlignmentu(ISequence seq1, ISequence seq2)
        {
            this.sekwencja1 = seq1;

            this.sekwencja2 = seq2;

            int N1 = sekwencja1.DługośćSekwencji();
            int N2 = sekwencja2.DługośćSekwencji();

            // +1 bo na spacje potrzeba dodatkowej komorki
            this.tablicaWartości = new int[N1+1, N2+1];
            this.tablicaStrzałek = new Kierunek[N1+1, N2+1];
        }


        private int[,] tablicaWartości;
        public int[,] Wartości
        {
            get { return tablicaWartości; }
            set { tablicaWartości = value; }
        }

        private Kierunek[,] tablicaStrzałek;

        public Kierunek[,] Kierunki
        {
            get { return tablicaStrzałek; }
            set { tablicaStrzałek = value; }
        }

        public void ZnajdzMaksymalnąWartośćIJejIndeksy(out int max, out int max_I, out int max_J)
        {
            max = int.MinValue;
            max_I = this.Wartości.GetLength(0) - 1;
            max_J = this.Wartości.GetLength(1) - 1;

            for (int i = 0; i < this.Wartości.GetLength(0); i++)
            {
                for (int j = 0; j < this.Wartości.GetLength(1); j++)
                {
                    if (this.Wartości[i, j] > max)
                    {
                        max = this.Wartości[i, j];
                        max_I = i;
                        max_J = j;
                    }
                }
            }
            
        }

        public void Wyświetl()
        {
            Console.WriteLine("\n\n");
            Console.Write("  ");
            foreach (var litera in sekwencja2.ZwróćLiteryPlusSpacjaNaPoczątku())
            {
                Console.Write("{0,5}",litera);
            }
            Console.WriteLine();
            Console.WriteLine();
            for (int i = 0; i < tablicaWartości.GetLength(0); i++)
            {
                Console.Write("{0,2}", sekwencja1.ZwróćLiteryPlusSpacjaNaPoczątku()[i] + "|");
                for (int j = 0; j < tablicaWartości.GetLength(1); j++)
                {
                    Console.Write("{0,5}",tablicaWartości[i,j]);
                }
                Console.WriteLine();
            }
        }

    }
}
