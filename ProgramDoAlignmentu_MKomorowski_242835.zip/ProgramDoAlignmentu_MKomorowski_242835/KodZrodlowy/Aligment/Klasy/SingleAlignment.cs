﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment.Klasy
{
    public class SingleAlignment
    {
        public string FirstSeq { get; set; }
        public string SecondSeq { get; set; }
        public string Indicators { get; set; } // linia umieszczona pomiedzy dwoma sekwencjami w konsoli pokazujaca zgodnosc
        //public int MaxScore { get; set; }

        public SingleAlignment()
        {
            this.FirstSeq = string.Empty;
            this.SecondSeq = string.Empty;
        }

        public void Wyswietl()
        {
            Console.WriteLine("\nAlignment: ");
            Console.WriteLine(this.FirstSeq);
            Console.WriteLine(this.Indicators);
            Console.WriteLine(this.SecondSeq);
        }

        public void Reverse()
        {
            char[] charArray = FirstSeq.ToCharArray();
            Array.Reverse(charArray);
            this.FirstSeq =  new string(charArray);
            
            charArray = Indicators.ToCharArray();
            Array.Reverse(charArray);
            this.Indicators = new string(charArray);

            charArray = SecondSeq.ToCharArray();
            Array.Reverse(charArray);
            this.SecondSeq = new string(charArray);
        }
    }
}
