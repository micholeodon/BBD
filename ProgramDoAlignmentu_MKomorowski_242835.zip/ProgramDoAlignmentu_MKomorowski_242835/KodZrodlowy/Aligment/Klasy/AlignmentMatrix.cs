﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment.Klasy
{
    public class AlignmentMatrix : AbsMacierzAlignmentu
    {
        public AlignmentMatrix(ISequence seq1, ISequence seq2) : base(seq1,seq2)
        {
        }
    }
}
