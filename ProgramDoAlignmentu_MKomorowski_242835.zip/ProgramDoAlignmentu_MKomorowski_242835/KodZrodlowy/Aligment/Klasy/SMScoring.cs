﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment.Klasy
{
    /// <summary>
    /// Class which scores match, mismatch and space according to loaded PAM Matrix.
    /// </summary>
    public class SMScoring : IScoring
    {
        private Dictionary<char, int> idCharMapper;
        private int[,] matrix;
        private string[] lines;
        private int spceScore;

        public SMScoring()
        {
            this.idCharMapper = new Dictionary<char, int>();
            LoadMatrix();
        }

        public int ComparisonScore(char letter1, char letter2)
        {
            var id1 = idCharMapper[letter1];
            var id2 = idCharMapper[letter2];

            return matrix[id1, id2];
        }

        public int SpaceScore()
        {
            return spceScore;
        }

        void LoadMatrix()
        {
            this.lines = File.ReadAllLines(ProgramConfig.set_substituteMatrixPath).Where(l=>!l.StartsWith("#")).ToArray();
            InitMapper();
            FillMatrix();
        }

        private void FillMatrix()
        {
            int matSize = this.idCharMapper.Count;
            this.matrix = new int[matSize, matSize];
            int row = 0;
            foreach (var line in lines)
            {
                if (line[0] == ' ' || line[0] == '*') continue;
                else
                {
                    for (int col = 0; col < matSize; col++)
                    {
                        string s = new string(new char[] { line[1 + 3 * col], line[1 + 3 * col + 1], line[1 + 3 * col + 2] });
                        int mij = Int32.Parse(s);
                        this.matrix[row, col] = mij;
                    }

                }
                row++;
            }
        }

        private void InitMapper()
        {
            int id = 0;
            foreach (var line in lines)
            {
                if (line[0] == ' ') continue;
                if (line[0] == '*')
                {
                    string s = new string(new char[] { line[1], line[2], line[3] });
                    spceScore = Int32.Parse(s);
                    continue;
                }
                char litera = line[0];
                idCharMapper.Add(litera, id);
                id++;


            }
        }



    }
}
