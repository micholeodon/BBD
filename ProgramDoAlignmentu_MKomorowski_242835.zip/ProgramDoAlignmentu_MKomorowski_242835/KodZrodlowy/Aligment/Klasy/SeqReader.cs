﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment.Klasy
{
    public class SeqReader
    {
        private string[] lines = null;
        public string[] SeqFile
        {
            get { return lines; }
            set { lines = value; }
        }

        #region Konstruktory
        /// <summary>
        /// Tworzy obiekt z domyslna sciezka do pliku z sekwencjami i wczytuje linie z tego pliku.
        /// </summary>
        public SeqReader()
        {
            SetDefaultPath();
        }
        /// <summary>
        /// Tworzy obiekt z ustalona sciezka do pliku z sekwencjami i wczytuje linie z tego pliku.
        /// </summary>
        /// <param name="fullpath"></param>
        public SeqReader(string fullpath)
        {
            SetCustomPath(fullpath);
        }
        #endregion


        /// <summary>
        /// Zwraca liste sekwencji  na podstawie pola lines.
        /// </summary>
        /// <returns></returns>
        public List<ISequence> ReadSequences()
        {
            List<ISequence> listOfSeqs = new List<ISequence>();
            if (lines == null)
            {
                Console.WriteLine("+ Nie wczytano pliku sekwencji !");
            }
            else
            {
                string linesToConcatenate = string.Empty;
                string info = string.Empty;
                bool gotInfo = false;
                foreach (var line in lines)
                {
                    // sperator sekwencji
                    if (line[0] == '>')
                    {
                        // co jeśli to pierwsza linia pliku?
                        if (linesToConcatenate == "")
                        {
                            info = line;
                            gotInfo = true;
                            continue;
                        };

                        // co gdy zaczyna sie nowa sekwencja?
                        ISequence seq = new Sequence(linesToConcatenate);
                        seq.DodajInfo(info);
                        info = string.Empty;
                        gotInfo = false;
                        listOfSeqs.Add(seq);
                        linesToConcatenate = string.Empty;
                        info = line;
                        gotInfo = true;
                    }
                    else
                    {
                        linesToConcatenate += line; // append line to sequence

                        // co gdy ostatnia linia pliku? Dopisujemy od ostatniej linii
                        if (line == lines[lines.Count() - 1]) 
                        {
                            ISequence seq = new Sequence(linesToConcatenate);
                            seq.DodajInfo(info);
                            info = string.Empty;
                            gotInfo = false;
                            listOfSeqs.Add(seq);
                            linesToConcatenate = string.Empty;
                        }
                    }

                }
            }
          


            return listOfSeqs;
        }

        public void ChangeFilePath(string newpath)
        {
            SetCustomPath(newpath);
        }

        private void SetDefaultPath()
        {
            this.lines = File.ReadAllLines(ProgramConfig.set_singleAligmentPath);
        }

        private void SetCustomPath(string fullpath)
        {
            this.lines = File.ReadAllLines(fullpath);
        }

    }
}
