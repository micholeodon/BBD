﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment.Klasy
{
    public class Sequence : ISequence
    {
        string kodLiterowy = null;
        public string info = "";

        public Sequence(string kod)
        {
            this.kodLiterowy = kod.Replace(" ", "");
        }


        public string ZwróćLitery()
        {
            return kodLiterowy;
        }


        public string ZwróćLiteryPlusSpacjaNaPoczątku()
        {
            return " " + kodLiterowy;
        }


        public int DługośćSekwencji()
        {
            if (kodLiterowy != null)
                return kodLiterowy.Length;
            else
                return 0;
        }


        public void DodajInfo(string info)
        {
            this.info = info.Replace(" ","");
        }


        public string ZwróćInfo()
        {
            return this.info;
        }
    }
}
