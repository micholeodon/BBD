﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment
{
    public static class ProgramConfig
    {
        // DEFAULT PARAMETERS of program

        public static string filesDirectory = LoadFilesFolder();

        // Please set these parameters to your demand.

        public static ProgramMode set_ProgramMode       =   ProgramMode.SingleAlignment;
        public static ScoringType set_ScoringType       =   ScoringType.SubstitutionMatrix;
        public static AlignmentType set_AlignmentType   =   AlignmentType.SmithWaterman;
        public static ShowAlignmentMatrix set_ShowAlignmentMatrix = ShowAlignmentMatrix.No;
        public static ENTER set_EnterMode               =   ENTER.No;
        

        // if ScoringType = Standard then program will use following weights:
        public static int set_sameLetterScore           =   5;
        public static int set_differentLetterScore      =   -2;
        public static int set_gapScore                  =   -6;

        // if AlignmentType = SmithWaterman then program will use following weights:
        public static int set_similarityThreshold       =   0;

        // follow the format of @" ... "
        public static string set_singleAligmentPath     = TestSingleAlignments.HOME_singleAligmentPath1;//@"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\seqTest2.fasta";
        public static string set_dbPath                 = TestDbAlignment.HOME_dbPath2;//@"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\DataBase.fasta.txt";
        public static string set_targetSequencesPath    = TestDbAlignment.HOME_targetPath1;//@"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\query_1.fasta.txt";
        public static string set_substituteMatrixPath   = TestSubstituteMatrices.HOME_MatrixPath3;//@"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\BLOSUM62.txt";




        #region Developer Classes

        // Please do not change this code !!!

        private static string LoadFilesFolder()
        {
            string[] lista = new string[] { };
            lista = Directory.GetDirectories(Directory.GetCurrentDirectory(), "Files", SearchOption.AllDirectories);

            return lista[0];
        }

        public enum ProgramMode
        {
            SingleAlignment,
            DbAlignment
        }

        public enum AlignmentType
        {
            NeedlemanWunsch,
            SmithWaterman
        }

        public enum ScoringType
        {
            Standard,
            SubstitutionMatrix
        }

        public enum ShowAlignmentMatrix
        {
            Yes,
            No
        }

        public enum ENTER
        {
            Yes,
            No
        }

        private static class TestSingleAlignments
        {
            // HOME - ścieżki dla domyslnej lokalizacji na komputerze osobistym
            public static string HOME_singleAligmentPath1 = @"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\seq.fasta";
            public static string HOME_singleAligmentPath2 = @"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\seqTest.fasta";
            public static string HOME_singleAligmentPath3 = @"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\seqTest2.fasta";
            
            // VIRTUAL - ścieżki na wirtualnych dyskach WFAiIS
            public static string VIRTUAL_singleAlignmentPath1 = @"K:\Studenci\PK\Prywatne\242835\BBD\Aligment\Aligment\Files\seq.fasta";
            public static string VIRTUAL_singleAlignmentPath2 = @"K:\Studenci\PK\Prywatne\242835\BBD\Aligment\Aligment\Files\seqTest.fasta";
            public static string VIRTUAL_singleAlignmentPath3 = @"K:\Studenci\PK\Prywatne\242835\BBD\Aligment\Aligment\Files\seqTest2.fasta";

        }

        private static class TestDbAlignment
        {
            // HOME - ścieżki dla domyslnej lokalizacji na komputerze osobistym
            public static string HOME_dbPath1 = @"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\DataBase.fasta.txt";
            public static string HOME_dbPath2 = @"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\dbTest.txt";
            public static string HOME_targetPath1 = @"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\query_1.fasta.txt";
            public static string HOME_targetPath2 = @"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\query_2.fasta.txt";
            public static string HOME_targetPath3 = @"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\query_3.fasta.txt";

            // VIRTUAL - ścieżki na wirtualnych dyskach WFAiIS
            public static string VIRTUAL_dbPath1 = @"K:\Studenci\PK\Prywatne\242835\BBD\Aligment\Aligment\Files\DataBase.fasta.txt";
            public static string VIRTUAL_dbPath2 = @"K:\Studenci\PK\Prywatne\242835\BBD\Aligment\Aligment\Files\dbTest.txt";
            public static string VIRTUAL_targetPath1 =  @"K:\Studenci\PK\Prywatne\242835\BBD\Aligment\Aligment\Files\query_1.fasta.txt";
            public static string VIRTUAL_targetPath2 = @"K:\Studenci\PK\Prywatne\242835\BBD\Aligment\Aligment\Files\query_2.fasta.txt";
            public static string VIRTUAL_targetPath3 = @"K:\Studenci\PK\Prywatne\242835\BBD\Aligment\Aligment\Files\query_3.fasta.txt";
        }

        public static class TestSubstituteMatrices
        {
            // HOME - ścieżki dla domyslnej lokalizacji na komputerze osobistym
            public static string HOME_MatrixPath1 = @"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\PAM250.txt";
            public static string HOME_MatrixPath2 = @"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\BLOSUM50.txt";
            public static string HOME_MatrixPath3 = @"D:\MICHU FOLDEUR\NAUKA\Studia - IS\II rok II sem\BBD\Aligment\Aligment\Files\BLOSUM62.txt";

            // VIRTUAL - ścieżki na wirtualnych dyskach WFAiIS
            public static string VIRTUAL_MatrixPath1 = @"K:\Studenci\PK\Prywatne\242835\BBD\Aligment\Aligment\Files\PAM250.txt";
            public static string VIRTUAL_MatrixPath2 = @"K:\Studenci\PK\Prywatne\242835\BBD\Aligment\Aligment\Files\BLOSUM50.txt";
            public static string VIRTUAL_MatrixPath3 = @"K:\Studenci\PK\Prywatne\242835\BBD\Aligment\Aligment\Files\BLOSUM62.txt";
        }

        #endregion
    }
}
