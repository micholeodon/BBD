﻿using Aligment.Klasy;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aligment
{
    class Program
    {
        static void Main(string[] args)
        {
            
            UserMenu.Configure();

            if (ProgramConfig.set_ProgramMode == ProgramConfig.ProgramMode.SingleAlignment)
                Program1();
            else if (ProgramConfig.set_ProgramMode == ProgramConfig.ProgramMode.DbAlignment)
                Program2();


            Console.WriteLine("\n\n\nWciśnij ENTER aby zakończyć ... ");
            
            Console.ReadLine();
        }


        /// <summary>
        /// Single sequence alignment.
        /// </summary>
        private static void Program1()
        {
            SeqReader seqReader = new SeqReader();
            List<ISequence> listaSq = seqReader.ReadSequences();

            AlignmentMatrix macierz = new AlignmentMatrix(listaSq[0], listaSq[1]);
            Aligner aligner = new Aligner(listaSq[0], listaSq[1], macierz);
            aligner.ObliczAlignmenty();

        }

        /// <summary>
        /// Database target alignment.
        /// </summary>
        private static void Program2()
        {

            SeqReader seqReader = new SeqReader();
            seqReader.ChangeFilePath(ProgramConfig.set_targetSequencesPath); 
            List<ISequence> listSeqTarget = seqReader.ReadSequences(); 
            seqReader.ChangeFilePath(ProgramConfig.set_dbPath); 
            List<ISequence> listSqDB = seqReader.ReadSequences(); 

         
            foreach(ISequence dbseq in listSeqTarget)
            {
                foreach(ISequence tseq in listSqDB)
                {
                    AlignmentMatrix macierz = new AlignmentMatrix(dbseq, tseq);
                    Aligner aligner = new Aligner(dbseq, tseq, macierz);
                    aligner.ObliczAlignmenty();

                    int x, y, max;
                    macierz.ZnajdzMaksymalnąWartośćIJejIndeksy(out max, out x, out y);
                    if (ProgramConfig.set_AlignmentType == ProgramConfig.AlignmentType.SmithWaterman && ProgramConfig.set_similarityThreshold > max)
                        continue;

                    if (ProgramConfig.set_EnterMode == ProgramConfig.ENTER.Yes)
                    {
                        Console.WriteLine("Wcisnij ENTER by przejsc do nastepnego porownaia ...");
                        Console.ReadLine();
                    }

                }
            }
           
        }
    }
}
